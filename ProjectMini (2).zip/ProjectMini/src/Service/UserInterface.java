package Service;

public interface UserInterface {
    void bookHotel(String userName, int hotelId);
    void viewBookings(String userName);
    void makePayment(int bookingId, double amount);
    void Local_Transport(String type, int locattransportId, Double price);
    void transport(String type, int transportId, Double price);
}
