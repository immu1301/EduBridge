package Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbConfig.DatabaseConnection;

public class UserService implements UserInterface {
    private final Connection connection;

    public UserService() {
        this.connection = DatabaseConnection.getConnection();
    }

    public boolean registerUser(String username, String password) {
        try {
            String query = "INSERT INTO users (username, password) VALUES (?, ?)";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.executeUpdate();
            System.out.println("User registered successfully!");
            return true;
        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) { // Duplicate entry error
                System.err.println("Username already exists. Please choose another one.");
            } else {
                System.err.println("Error registering user.");
                e.printStackTrace();
            }
            return false;
        }
    }

    public boolean loginUser(String username, String password) {
        try {
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("Login successful! Welcome, " + username);
                return true;
            } else {
                System.err.println("Invalid username or password. Please try again.");
                return false;
            }
        } catch (SQLException e) {
            System.err.println("Error logging in.");
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void bookHotel(String userName, int hotelId) {
        try {
            String query = "INSERT INTO bookings (user_name, hotel_id) VALUES (?, ?)";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, userName);
            ps.setInt(2, hotelId);
            ps.executeUpdate();
            System.out.println("Hotel booked successfully for " + userName);
        } catch (SQLException e) {
            System.err.println("Error booking hotel.");
            e.printStackTrace();
        }
    }

    @Override
    public void viewBookings(String userName) {
        try {
            String query = "SELECT b.booking_id, h.location, h.price, b.booking_date " +
                           "FROM bookings b " +
                           "JOIN hotels h ON b.hotel_id = h.id " +
                           "WHERE b.user_name = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, userName);
            ResultSet rs = ps.executeQuery();

            System.out.println("Bookings for " + userName + ":");
            while (rs.next()) {
                System.out.println("Booking ID: " + rs.getInt("booking_id"));
                System.out.println("Hotel Location: " + rs.getString("location"));
                System.out.println("Price: " + rs.getDouble("price"));
                System.out.println("Booking Date: " + rs.getTimestamp("booking_date"));
                System.out.println("-----------------------------------");
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving bookings.");
            e.printStackTrace();
        }
    }

    @Override
    public void makePayment(int bookingId, double amount) {
        try {
            String query = "INSERT INTO payments (booking_id, amount_paid) VALUES (?, ?)";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, bookingId);
            ps.setDouble(2, amount);
           
            ps.executeUpdate();
            System.out.println("Payment recorded. Amount Paid: " + amount );
        } catch (SQLException e) {
            System.err.println("Error recording payment.");
            e.printStackTrace();
        }
    }

	public void bookTransport(String type, int transportId, double price) {
		// TODO Auto-generated method stub
		 try {
	            String query = "INSERT INTO transports (type , transport_id, price) VALUES (?, ?, ?)";
	            PreparedStatement ps = connection.prepareStatement(query);
	            ps.setInt(1, transportId);
	            ps.setString(2, type);
	            ps.setDouble(3, price);
	           
	            ps.executeUpdate();
	            System.out.println("Transport recorded. Amount Paid: " + transportId );
	        } catch (SQLException e) {
	            System.err.println("Error recording transport.");
	            e.printStackTrace();
	        }
		
	}

	public void bookLocalTransport(String type, int Id, double price) {
		// TODO Auto-generated method stub
		 try {
	            String query = "INSERT INTO local_transports (id, type, price) VALUES (?, ?, ?)";
	            PreparedStatement ps = connection.prepareStatement(query);
	            ps.setInt(1, Id);
	            ps.setString(2, type);
	            ps.setDouble(3, price);
	           
	            ps.executeUpdate();
	            System.out.println("Local_Transport recorded. Amount Paid: " + Id );
	        } catch (SQLException e) {
	            System.err.println("Error recording Local_transport.");
	            e.printStackTrace();
	        }
	}

	public void Local_Transport(int locattransportId, String type, Double price) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void transport(String type, int transportId, Double price) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Local_Transport(String type, int locattransportId, Double price) {
		// TODO Auto-generated method stub
		
	}
}
