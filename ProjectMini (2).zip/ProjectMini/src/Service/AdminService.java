package Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbConfig.DatabaseConnection;
import model.Hotel;
import model.LocalTransport;
import model.Transport;

public class AdminService implements AdminInterface {
    private final Connection connection;

    public AdminService() {
        this.connection = DatabaseConnection.getConnection();
    }

    @Override
    public void addHotel(Hotel hotel) {
        try {
            String query = "INSERT INTO hotels (id, location, price) VALUES (?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, hotel.id);
            ps.setString(2, hotel.location);
            ps.setDouble(3, hotel.price);
            ps.executeUpdate();
            System.out.println("Hotel added: " + hotel);
        } catch (SQLException e) {
            System.err.println("Error adding hotel.");
            e.printStackTrace();
        }
    }

    @Override
    public void updateHotel(int id, String location, double price) {
        try {
            String query = "UPDATE hotels SET location = ?, price = ? WHERE id = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, location);
            ps.setDouble(2, price);
            ps.setInt(3, id);
            ps.executeUpdate();
            System.out.println("Hotel updated: ID=" + id);
        } catch (SQLException e) {
            System.err.println("Error updating hotel.");
            e.printStackTrace();
        }
    }

    @Override
    public void deleteHotel(int id) {
        try {
            String query = "DELETE FROM hotels WHERE id = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Hotel deleted: ID=" + id);
        } catch (SQLException e) {
            System.err.println("Error deleting hotel.");
            e.printStackTrace();
        }
    }

    @Override
    public Hotel selectHotel(int id) {
        try {
            String query = "SELECT * FROM hotels WHERE id = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Hotel(rs.getInt("id"), rs.getString("location"), rs.getDouble("price"));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving hotel.");
            e.printStackTrace();
        }
        return null;
    }


	@Override
	public void addTransport(Transport transport) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateTransport(int id, String type, double price) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteTransport(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Transport selectTransport(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addLocalTransport(LocalTransport localTransport) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateLocalTransport(int id, String type, double price) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteLocalTransport(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public LocalTransport selectLocalTransport(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean loginAdmin(String adminUsername, String adminPassword) {
		// TODO Auto-generated method stub
		return false;
	}

	public Object viewTransport() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object viewLocalTransport() {
		// TODO Auto-generated method stub
		return null;
	}

    // Similar implementations for Transport and LocalTransport
}
