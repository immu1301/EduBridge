package TestProject;

import java.util.Scanner;

import Service.AdminService;
import Service.UserService;
import model.Hotel;
import model.LocalTransport;
import model.Transport;

public class TravelApplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AdminService adminService = new AdminService();
        UserService userService = new UserService();

        while (true) {
            System.out.println("\nWelcome to the Travel Application");
            System.out.print("Are you an Admin or a User? (Admin/User/Exit): ");
            String role = scanner.nextLine();

            if (role.equalsIgnoreCase("Admin")) {
                boolean exitAdmin = false;
                while (!exitAdmin) {
                    System.out.println("\nAdmin Options:");
                    System.out.println("1. Manage Hotels");
                    System.out.println("2. Manage Transport");
                    System.out.println("3. Manage Local Transport");
                    System.out.println("4. Logout");
                    System.out.print("Choose an option: ");
                    int adminChoice = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    switch (adminChoice) {
                        case 1 -> {
                            System.out.println("\nHotel Management:");
                            System.out.println("1. Add Hotel");
                            System.out.println("2. Update Hotel");
                            System.out.println("3. Delete Hotel");
                            System.out.println("4. Select Hotel");
                            System.out.print("Choose an option: ");
                            int hotelChoice = scanner.nextInt();
                            scanner.nextLine();

                            switch (hotelChoice) {
                                case 1 -> {
                                    System.out.print("Enter Hotel ID: ");
                                    int id = scanner.nextInt();
                                    scanner.nextLine();
                                    System.out.print("Enter Hotel Location: ");
                                    String location = scanner.nextLine();
                                    System.out.print("Enter Hotel Price: ");
                                    double price = scanner.nextDouble();
                                    adminService.addHotel(new Hotel(id, location, price));
                                }
                                case 2 -> {
                                    System.out.print("Enter Hotel ID to Update: ");
                                    int id = scanner.nextInt();
                                    scanner.nextLine();
                                    System.out.print("Enter New Location: ");
                                    String location = scanner.nextLine();
                                    System.out.print("Enter New Price: ");
                                    double price = scanner.nextDouble();
                                    adminService.updateHotel(id, location, price);
                                }
                                case 3 -> {
                                    System.out.print("Enter Hotel ID to Delete: ");
                                    int id = scanner.nextInt();
                                    adminService.deleteHotel(id);
                                }
                                case 4 -> {
                                    System.out.print("Enter Hotel ID to Select: ");
                                    int id = scanner.nextInt();
                                    Hotel hotel = adminService.selectHotel(id);
                                    if (hotel != null) {
                                        System.out.println(hotel);
                                    } else {
                                        System.out.println("Hotel not found.");
                                    }
                                }
                                default -> System.out.println("Invalid option. Try again.");
                            }
                        }
                        case 2 -> {
                            System.out.println("\nTransport Management:");
                            System.out.println("1. Add Transport");
                            System.out.println("2. Update Transport");
                            System.out.println("3. View Transport");
                            System.out.print("Choose an option: ");
                            int transportChoice = scanner.nextInt();
                            scanner.nextLine();

                            switch (transportChoice) {
                                case 1 -> {
                                    System.out.print("Enter Transport ID: ");
                                    int id = scanner.nextInt();
                                    scanner.nextLine();
                                    System.out.print("Enter Transport Type: ");
                                    String type = scanner.nextLine();
                                    System.out.print("Enter Transport Price: ");
                                    double price = scanner.nextDouble();
                                    adminService.addTransport(new Transport(id, type, price));
                                }
                                case 2 -> {
                                    System.out.print("Enter Transport ID to Update: ");
                                    int id = scanner.nextInt();
                                    scanner.nextLine();
                                    System.out.print("Enter New Type: ");
                                    String type = scanner.nextLine();
                                    System.out.print("Enter New Price: ");
                                    double price = scanner.nextDouble();
                                    adminService.updateTransport(id, type, price);
                                }
                                case 3 -> adminService.viewTransport();
                                default -> System.out.println("Invalid option. Try again.");
                            }
                        }
                        case 3 -> {
                            System.out.println("\nLocal Transport Management:");
                            System.out.println("1. Add Local Transport");
                            System.out.println("2. Update Local Transport");
                            System.out.println("3. View Local Transport");
                            System.out.print("Choose an option: ");
                            int localTransportChoice = scanner.nextInt();
                            scanner.nextLine();

                            switch (localTransportChoice) {
                                case 1 -> {
                                    System.out.print("Enter Local Transport ID: ");
                                    int id = scanner.nextInt();
                                    scanner.nextLine();
                                    System.out.print("Enter Local Transport Type: ");
                                    String type = scanner.nextLine();
                                    scanner.nextLine();
                                    System.out.print("Enter Local Transport Price: ");
                                    double price = scanner.nextDouble();
                                    adminService.addLocalTransport(new LocalTransport(id, type, price));
                                }
                                case 2 -> {
                                    System.out.print("Enter Local Transport ID to Update: ");
                                    int id = scanner.nextInt();
                                    scanner.nextLine();
                                    System.out.print("Enter New Type: ");
                                    String type = scanner.nextLine();
                                    System.out.print("Enter New Price: ");
                                    double price = scanner.nextDouble();
                                    adminService.updateLocalTransport(id, type, price);
                                }
                                case 3 -> adminService.viewLocalTransport();
                                default -> System.out.println("Invalid option. Try again.");
                            }
                        }
                        case 4 -> exitAdmin = true;
                        default -> System.out.println("Invalid option. Try again.");
                    }
                }
            } else if (role.equalsIgnoreCase("User")) {
                System.out.println("\nUser Options:");
                System.out.println("1. Register");
                System.out.println("2. Login");
                System.out.print("Choose an option: ");
                int userChoice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                String userName = null;
                if (userChoice == 1) {
                    System.out.print("Enter a username: ");
                    userName = scanner.nextLine();
                    System.out.print("Enter a password: ");
                    String password = scanner.nextLine();
                    if (!userService.registerUser(userName, password)) {
                        continue;
                    }
                } else if (userChoice == 2) {
                    System.out.print("Enter your username: ");
                    userName = scanner.nextLine();
                    System.out.print("Enter your password: ");
                    String password = scanner.nextLine();
                    if (!userService.loginUser(userName, password)) {
                        continue;
                    }
                } else {
                    System.out.println("Invalid option. Returning to main menu.");
                    continue;
                }

                boolean exitUser = false;
                while (!exitUser) {
                    System.out.println("\nUser Options:");
                    System.out.println("1. Book Hotel");
                    System.out.println("2. Book Transport");
                    System.out.println("3. Book Local Transport");
                    System.out.println("4. View Bookings");
                    System.out.println("5. Make Payment");
                    System.out.println("6. Logout");
                    System.out.print("Choose an option: ");
                    int userAction = scanner.nextInt();
                    scanner.nextLine();

                    switch (userAction) {
                        case 1 -> {
                            System.out.print("Enter Hotel ID to Book: ");
                            int hotelId = scanner.nextInt();
                            userService.bookHotel(userName, hotelId);
                        }
                        case 2 -> {
                            System.out.print("Enter Transport ID to Book: ");
                            int transportId = scanner.nextInt();
                            String type = scanner.toString();
                            double price = scanner.nextDouble();
                            userService.bookTransport(type, transportId, price);
                        }
                        case 3 -> {
                            System.out.print("Enter Local Transport ID to Book: ");
                            int localTransportId = scanner.nextInt();
                            System.out.print("Enter type to Book: ");
                            String type = scanner.next();
                            System.out.print("Enter Local Transport price to Book: ");
							double price = scanner.nextDouble();
							userService.bookLocalTransport(type, localTransportId, price);
                        }
                        case 4 -> userService.viewBookings(userName); 
                        case 5 -> {
                            System.out.print("Enter Booking ID: ");
                            int bookingId = scanner.nextInt();
                            System.out.print("Enter Amount to Pay: ");
                            double amount = scanner.nextDouble();
                            
                            userService.makePayment(bookingId, amount);
                        }
                        case 6 -> exitUser = true;
                        default -> System.out.println("Invalid option. Try again.");
                    }
                }
            } else if (role.equalsIgnoreCase("Exit")) {
                System.out.println("Exiting the application. Goodbye!");
                break;
            } else {
                System.out.println("Invalid role. Please choose either 'Admin', 'User', or 'Exit'.");
            }
        }

        scanner.close();
    }
}
